## The extension has the followinf properties or features.

1. The extension uses the blacklist filtering to remove teh bad urls
2. the extension uses alerting systems oncertain types of sites that m ay have potential to be threatful iin any possible nature.
3. the extension allows the user to navigate to the authentic siurce of a siftware like VLC etc
4. The extension allows the user to be safe from any locally hosted servers like a reverseshell , a local server
5. the extension saves the user from attending any http url .
6. the url allows the user to be safe from any dark web portal that ends with a .onion subdomain.
7. The extension allows the trusted sites like google etc to pass through while maintaining the black and a white list simultaneously.
8. the extension allows the user to keep a check on all teh requested urls in a GUI form that are often missed by he user .
9. the extension saves the important information like the url  typoe , request id , get , wcode etc in the gui form and in the chrome local storage.
10. The user data does not leave his or her system rather the extension prepares a machine learning model that sendsout the weights and behaviours that is accumulated while parsing through numerous urls.

